#include <iostream>
#include <string>
#include <vector>
#include <algorithm> // For std::transform, std::find
#include <ctime>     // For std::time, std::srand
#include <cctype>    // For ::toupper
#include <map>
#include <iomanip>   // For std::setw (though not heavily used here)
#include <cstdlib>   // For std::rand, std::srand, system("cls")
#include <limits>    // For std::numeric_limits
#define NOMINMAX     // Prevents min/max macros from conflicting with std::numeric_limits
#include <windows.h> // For Sleep()
#include <conio.h>   // For _kbhit(), _getch()

// Using namespace std; is generally discouraged in headers but common in small projects.
// For compatibility, we'll keep it as in the original, but be aware for larger projects.
using namespace std;

// Forward declarations for helper functions that will replace lambdas
// These are made free functions for simplicity, or could be static members of the class.
void displayTicTacToeBoard(const vector<vector<char>>& board);
bool checkTicTacToeWin(const vector<vector<char>>& board, char player);
bool isTicTacToeBoardFull(const vector<vector<char>>& board);
void displayReversiBoard(const vector<vector<char>>& board);
bool isValidReversiMove(const vector<vector<char>>& board, int row, int col, char player);
void makeReversiMove(vector<vector<char>>& board, int row, int col, char player);
bool hasValidReversiMoves(const vector<vector<char>>& board, char player);
pair<int, int> countReversiPieces(const vector<vector<char>>& board);
// Renamed 'board' parameter to 'gameGrid' in declarations to avoid potential conflicts
void displaySnakeBoard(const vector<vector<char>>& gameGrid, int width, int height, int score);
void displayPongBoard(const vector<vector<char>>& gameGrid, int width, int height, int playerScore, int computerScore);


class PlayWareLegacyEditionHub {
private:
    // Word lists - initialized in constructor for VS2010 compatibility
    vector<string> wordle_words;
    vector<string> hangman_words;
    vector<string> contexto_words;
    
    // Mad Libs templates
    vector<vector<string>> madlib_templates;
    
    // Would You Rather questions
    vector<pair<string, string>> wyr_questions;
    
public:
    PlayWareLegacyEditionHub() {
        // Initialize random seed
        srand(static_cast<unsigned int>(time(0)));

        // Initialize word lists
        wordle_words.push_back("APPLE");
        wordle_words.push_back("BRAVE");
        wordle_words.push_back("CHAIR");
        wordle_words.push_back("DRIVE");
        wordle_words.push_back("EARTH");
        wordle_words.push_back("FOCUS");
        wordle_words.push_back("GRACE");
        wordle_words.push_back("HEART");
        wordle_words.push_back("LIGHT");
        wordle_words.push_back("MAGIC");

        hangman_words.push_back("COMPUTER");
        hangman_words.push_back("ELEPHANT");
        hangman_words.push_back("RAINBOW");
        hangman_words.push_back("JOURNEY");
        hangman_words.push_back("FREEDOM");
        hangman_words.push_back("MYSTERY");
        hangman_words.push_back("ADVENTURE");
        hangman_words.push_back("KEYBOARD");
        hangman_words.push_back("SANDWICH");
        hangman_words.push_back("TELEPHONE");

        contexto_words.push_back("WATER");
        contexto_words.push_back("MUSIC");
        contexto_words.push_back("HAPPY");
        contexto_words.push_back("DREAM");
        contexto_words.push_back("SPACE");
        contexto_words.push_back("HOUSE");
        contexto_words.push_back("QUICK");
        contexto_words.push_back("MONEY");
        contexto_words.push_back("SMILE");
        contexto_words.push_back("PEACE");

        // Initialize Mad Libs templates
        vector<string> template1;
        template1.push_back("The"); template1.push_back("ADJECTIVE"); template1.push_back("cat"); template1.push_back("VERB");
        template1.push_back("over the"); template1.push_back("NOUN"); template1.push_back("and"); template1.push_back("ADVERB");
        template1.push_back("landed on a"); template1.push_back("ADJECTIVE"); template1.push_back("NOUN");
        madlib_templates.push_back(template1);

        vector<string> template2;
        template2.push_back("I"); template2.push_back("ADVERB"); template2.push_back("VERB"); template2.push_back("to the");
        template2.push_back("NOUN"); template2.push_back("where I met a"); template2.push_back("ADJECTIVE"); template2.push_back("PERSON");
        template2.push_back("who was"); template2.push_back("VERB"); template2.push_back("a"); template2.push_back("NOUN");
        madlib_templates.push_back(template2);

        vector<string> template3;
        template3.push_back("Yesterday, I"); template3.push_back("VERB"); template3.push_back("my"); template3.push_back("ADJECTIVE");
        template3.push_back("NOUN"); template3.push_back("and it"); template3.push_back("ADVERB"); template3.push_back("VERB");
        template3.push_back("into a"); template3.push_back("ADJECTIVE"); template3.push_back("NOUN");
        madlib_templates.push_back(template3);

        vector<string> template4;
        template4.push_back("The"); template4.push_back("ADJECTIVE"); template4.push_back("PERSON"); template4.push_back("ADVERB");
        template4.push_back("VERB"); template4.push_back("through the"); template4.push_back("NOUN"); template4.push_back("carrying a");
        template4.push_back("ADJECTIVE"); template4.push_back("NOUN"); template4.push_back("full of"); template4.push_back("PLURAL_NOUN");
        madlib_templates.push_back(template4);

        // Initialize Would You Rather questions
        wyr_questions.push_back(make_pair("Have the ability to fly", "Have the ability to become invisible"));
        wyr_questions.push_back(make_pair("Always be 10 minutes late", "Always be 20 minutes early"));
        wyr_questions.push_back(make_pair("Live without music", "Live without movies"));
        wyr_questions.push_back(make_pair("Have super strength", "Have super speed"));
        wyr_questions.push_back(make_pair("Always speak your mind", "Never speak again"));
        wyr_questions.push_back(make_pair("Be able to read minds", "Be able to predict the future"));
        wyr_questions.push_back(make_pair("Live in a world without colors", "Live in a world without sounds"));
        wyr_questions.push_back(make_pair("Have unlimited money", "Have unlimited time"));
        wyr_questions.push_back(make_pair("Always be too hot", "Always be too cold"));
        wyr_questions.push_back(make_pair("Fight 100 duck-sized horses", "Fight 1 horse-sized duck"));
    }
    
    void displayLogo() {
        cout << "\n";
        cout << "========================================================================\n";
        cout << "               P L A Y W A R E   L E G A C Y   E D I T I O N\n";
        cout << "========================================================================\n";
        cout << "\n                    Your Ultimate Gaming Hub!\n\n";
    }
    
    void displayMenu() {
        cout << "\n[Game] GAME MENU [Game]\n";
        cout << "================\n";
        cout << "1. Wordle\n";
        cout << "2. Hangman (Lives System)\n";
        cout << "3. Tic Tac Toe\n";
        cout << "4. Rock Paper Scissors\n";
        cout << "5. Contexto\n";
        cout << "6. Mad Libs\n";
        cout << "7. Number Guessing\n";
        cout << "8. Would You Rather\n";
        cout << "9. Reversi\n";
        cout << "10. Snake\n";
        cout << "11. Pong\n";
        cout << "12. Exit\n";
        cout << "\nChoose a game (1-12): ";
    }
    
    void playWordle() {
        string word = wordle_words[rand() % wordle_words.size()];
        string guess;
        int attempts = 6;
        vector<string> guesses;
        
        cout << "\n[Target] WORDLE [Target]\n";
        cout << "=============\n";
        cout << "Guess the 5-letter word! You have 6 attempts.\n";
        cout << "[Green] = Correct letter in correct position\n";
        cout << "[Yellow] = Correct letter in wrong position\n";
        cout << "[Gray] = Letter not in word\n\n";
        
        while (attempts > 0) {
            cout << "Attempts left: " << attempts << "\n";
            cout << "Enter your guess: ";
            cin >> guess;
            
            transform(guess.begin(), guess.end(), guess.begin(), ::toupper);
            
            if (guess.length() != 5) {
                cout << "Please enter a 5-letter word!\n";
                continue;
            }
            
            guesses.push_back(guess);
            
            if (guess == word) {
                cout << "\n(Hooray!) Congratulations! You guessed it: " << word << "\n";
                cout << "You won in " << (7 - attempts) << " attempts!\n";
                return;
            }
            
            // Display feedback
            string feedback = "";
            for (int i = 0; i < 5; i++) {
                if (guess[i] == word[i]) {
                    feedback += "[Green]";
                } else if (word.find(guess[i]) != string::npos) {
                    feedback += "[Yellow]";
                } else {
                    feedback += "[Gray]";
                }
            }
            
            cout << guess << " " << feedback << "\n";
            attempts--;
        }
        
        cout << "\n(Game Over) Game Over! The word was: " << word << "\n";
    }
    
    void playHangman() {
        string word = hangman_words[rand() % hangman_words.size()];
        string guessed(word.length(), '_');
        vector<char> wrong_letters;
        int lives = 6;
        
        cout << "\n(Hangman) HANGMAN (Hangman)\n";
        cout << "===============\n";
        cout << "Guess the word letter by letter!\n";
        cout << "You have " << lives << " lives.\n\n";
        
        while (lives > 0 && guessed != word) {
            cout << "Lives: ";
            for (int i = 0; i < lives; i++) cout << "<3 ";
            cout << "\n";
            
            cout << "Word: " << guessed << "\n";
            cout << "Wrong letters: ";
            // Fix: Replaced C++11 range-based for loop with traditional for loop
            for (size_t i = 0; i < wrong_letters.size(); ++i) {
                cout << wrong_letters[i] << " ";
            }
            cout << "\n";
            
            cout << "Enter a letter: ";
            char letter;
            cin >> letter;
            letter = toupper(letter);
            
            // Check if letter was already guessed (wrong or correct)
            bool alreadyGuessed = false;
            if (word.find(letter) != string::npos) { // Check if it's a correct letter
                for (int i = 0; i < (int)word.length(); ++i) { // Fix: signed/unsigned mismatch
                    if (word[i] == letter && guessed[i] == letter) {
                        alreadyGuessed = true;
                        break;
                    }
                }
            } else { // Check if it's a wrong letter
                if (find(wrong_letters.begin(), wrong_letters.end(), letter) != wrong_letters.end()) {
                    alreadyGuessed = true;
                }
            }

            if (alreadyGuessed) {
                cout << "(Info) You already guessed that letter! Try again.\n";
            } else if (word.find(letter) != string::npos) {
                cout << "(Correct) Good guess!\n";
                for (int i = 0; i < (int)word.length(); i++) { // Fix: signed/unsigned mismatch
                    if (word[i] == letter) {
                        guessed[i] = letter;
                    }
                }
            } else {
                cout << "(Wrong) Wrong letter!\n";
                wrong_letters.push_back(letter);
                lives--;
            }
            cout << "\n";
        }
        
        if (guessed == word) {
            cout << "(Hooray!) Congratulations! You guessed: " << word << "\n";
        } else {
            cout << "(Game Over) Game Over! The word was: " << word << "\n";
        }
    }
    
    void playTicTacToe() {
        vector<vector<char>> board(3, vector<char>(3, ' '));
        char currentPlayer = 'X';
        
        cout << "\n(O) TIC TAC TOE (O)\n";
        cout << "==================\n";
        cout << "Player X vs Player O\n";
        cout << "Enter positions as row,col (1-3)\n\n";
        
        int moves = 0;
        while (moves < 9) {
            displayTicTacToeBoard(board); // Use helper function
            cout << "Player " << currentPlayer << "'s turn\n";
            cout << "Enter row (1-3): ";
            int row;
            cin >> row;
            cout << "Enter column (1-3): ";
            int col;
            cin >> col;
            
            row--; col--; // Convert to 0-indexed
            
            if (row < 0 || row > 2 || col < 0 || col > 2 || board[row][col] != ' ') {
                cout << "Invalid move! Try again.\n";
                continue;
            }
            
            board[row][col] = currentPlayer;
            moves++;
            
            if (checkTicTacToeWin(board, currentPlayer)) { // Use helper function
                displayTicTacToeBoard(board);
                cout << "(Hooray!) Player " << currentPlayer << " wins!\n";
                return;
            }
            
            if (isTicTacToeBoardFull(board)) { // Use helper function
                displayTicTacToeBoard(board);
                cout << "(Tie) It's a tie!\n";
                return;
            }
            
            currentPlayer = (currentPlayer == 'X') ? 'O' : 'X';
        }
    }
    
    void playRockPaperScissors() {
        vector<string> choices;
        choices.push_back("Rock");
        choices.push_back("Paper");
        choices.push_back("Scissors");

        vector<string> text_icons;
        text_icons.push_back("[Rock]");
        text_icons.push_back("[Paper]");
        text_icons.push_back("[Scissors]");

        int playerScore = 0, computerScore = 0;
        
        cout << "\n[Rock][Paper][Scissors] ROCK PAPER SCISSORS [Scissors][Paper][Rock]\n";
        cout << "===================================\n";
        cout << "Best of 5 rounds!\n";
        cout << "1 = Rock, 2 = Paper, 3 = Scissors\n\n";
        
        while (playerScore < 3 && computerScore < 3) {
            cout << "Score - You: " << playerScore << " | Computer: " << computerScore << "\n";
            cout << "Your choice (1-3): ";
            int playerChoice;
            cin >> playerChoice;
            
            if (playerChoice < 1 || playerChoice > 3) {
                cout << "Invalid choice! Try again.\n";
                continue;
            }
            
            playerChoice--; // Convert to 0-indexed
            int computerChoice = rand() % 3; // Use rand()
            
            cout << "You chose: " << text_icons[playerChoice] << " " << choices[playerChoice] << "\n";
            cout << "Computer chose: " << text_icons[computerChoice] << " " << choices[computerChoice] << "\n";
            
            if (playerChoice == computerChoice) {
                cout << "(Tie) It's a tie!\n";
            } else if ((playerChoice == 0 && computerChoice == 2) ||
                      (playerChoice == 1 && computerChoice == 0) ||
                      (playerChoice == 2 && computerChoice == 1)) {
                cout << "(Hooray!) You win this round!\n";
                playerScore++;
            } else {
                cout << "(Computer) Computer wins this round!\n";
                computerScore++;
            }
            cout << "\n";
        }
        
        if (playerScore > computerScore) {
            cout << "(Trophy) You won the game! Final Score: " << playerScore << "-" << computerScore << "\n";
        } else {
            cout << "(Computer) Computer won the game! Final Score: " << computerScore << "-" << playerScore << "\n";
        }
    }
    
    void playContexto() {
        string word = contexto_words[rand() % contexto_words.size()]; // Use rand()
        string guess;
        int attempts = 8;
        vector<string> guesses;
        
        cout << "\n[Target] CONTEXTO [Target]\n";
        cout << "================\n";
        cout << "Guess the secret word based on context clues!\n";
        cout << "You have " << attempts << " attempts.\n";
        cout << "I'll give you hints based on how close your guess is!\n\n";
        
        // Context hints based on the word
        map<string, vector<string>> hints;
        
        vector<string> waterHints; waterHints.push_back("It's essential for life"); waterHints.push_back("You drink it"); waterHints.push_back("It's liquid"); waterHints.push_back("Found in oceans");
        hints["WATER"] = waterHints;

        vector<string> musicHints; musicHints.push_back("You hear it"); musicHints.push_back("It has rhythm"); musicHints.push_back("Made with instruments"); musicHints.push_back("Can be sung");
        hints["MUSIC"] = musicHints;

        vector<string> happyHints; happyHints.push_back("It's an emotion"); happyHints.push_back("Opposite of sad"); happyHints.push_back("Makes you smile"); happyHints.push_back("Positive feeling");
        hints["HAPPY"] = happyHints;

        vector<string> dreamHints; dreamHints.push_back("Happens when you sleep"); dreamHints.push_back("Can be about the future"); dreamHints.push_back("Sometimes scary"); dreamHints.push_back("In your mind");
        hints["DREAM"] = dreamHints;

        vector<string> spaceHints; spaceHints.push_back("It's vast"); spaceHints.push_back("Contains stars"); spaceHints.push_back("Astronauts go there"); spaceHints.push_back("Above Earth");
        hints["SPACE"] = spaceHints;

        vector<string> houseHints; houseHints.push_back("You live in it"); houseHints.push_back("Has rooms"); houseHints.push_back("Provides shelter"); houseHints.push_back("Has a door");
        hints["HOUSE"] = houseHints;

        vector<string> quickHints; quickHints.push_back("It's fast"); quickHints.push_back("Opposite of slow"); quickHints.push_back("Rapid movement"); quickHints.push_back("Speedy");
        hints["QUICK"] = quickHints;

        vector<string> moneyHints; moneyHints.push_back("You spend it"); moneyHints.push_back("Can buy things"); moneyHints.push_back("Currency"); moneyHints.push_back("In your wallet");
        hints["MONEY"] = moneyHints;

        vector<string> smileHints; smileHints.push_back("Expression of joy"); smileHints.push_back("Shows teeth"); smileHints.push_back("On your face"); smileHints.push_back("When happy");
        hints["SMILE"] = smileHints;

        vector<string> peaceHints; peaceHints.push_back("Opposite of war"); peaceHints.push_back("Calm and quiet"); peaceHints.push_back("Harmony"); peaceHints.push_back("No conflict");
        hints["PEACE"] = peaceHints;
        
        while (attempts > 0) {
            cout << "Attempts left: " << attempts << "\n";
            
            // Give progressive hints
            int hintIndex = 8 - attempts;
            if (hintIndex < (int)hints[word].size()) { // Fix: signed/unsigned mismatch
                cout << "(Hint) Hint: " << hints[word][hintIndex] << "\n";
            }
            
            cout << "Your guess: ";
            cin >> guess;
            transform(guess.begin(), guess.end(), guess.begin(), ::toupper);
            
            if (guess == word) {
                cout << "\n(Hooray!) Excellent! You guessed it: " << word << "\n";
                cout << "You won in " << (9 - attempts) << " attempts!\n";
                return;
            }
            
            // Give feedback based on similarity
            int similarity = 0;
            for (size_t i = 0; i < guess.length(); ++i) { // Use size_t for loop counter
                if (word.find(guess[i]) != string::npos) similarity++;
            }
            
            if (similarity > (int)word.length() / 2) { // Cast to int for comparison
                cout << "(Hot) Very close! You're on the right track!\n";
            } else if (similarity > 0) {
                cout << "(Warm) Some letters match, but not quite there!\n";
            } else {
                cout << "(Cold) Not close at all, try thinking differently!\n";
            }
            
            attempts--;
            cout << "\n";
        }
        
        cout << "(Game Over) Game Over! The word was: " << word << "\n";
    }
    
    void playMadLibs() {
        cout << "\n(Mad Libs) MAD LIBS (Mad Libs)\n";
        cout << "================\n";
        cout << "Fill in the blanks to create a funny story!\n\n";
        
        vector<string> template_story = madlib_templates[rand() % madlib_templates.size()]; // Use rand()
        vector<string> user_words;
        
        cin.ignore(); // Clear the input buffer
        
        cout << "I need some words from you:\n";
        
        for (size_t i = 0; i < template_story.size(); i++) { // Use size_t
            if (template_story[i].find("ADJECTIVE") != string::npos ||
                template_story[i].find("NOUN") != string::npos ||
                template_story[i].find("VERB") != string::npos ||
                template_story[i].find("ADVERB") != string::npos ||
                template_story[i].find("PERSON") != string::npos ||
                template_story[i].find("PLURAL") != string::npos) {
                
                cout << "Give me a " << template_story[i] << ": ";
                string word;
                getline(cin, word);
                user_words.push_back(word);
            }
        }
        
        cout << "\n(Story) Here's your Mad Lib story:\n";
        cout << "================================\n";
        
        int word_index = 0;
        for (size_t i = 0; i < template_story.size(); i++) { // Use size_t
            if (template_story[i].find("ADJECTIVE") != string::npos ||
                template_story[i].find("NOUN") != string::npos ||
                template_story[i].find("VERB") != string::npos ||
                template_story[i].find("ADVERB") != string::npos ||
                template_story[i].find("PERSON") != string::npos ||
                template_story[i].find("PLURAL") != string::npos) {
                
                cout << user_words[word_index++];
            } else {
                cout << template_story[i];
            }
            
            if (i < template_story.size() - 1) cout << " ";
        }
        cout << "!\n\n";
        cout << "(Hooray!) Hope you enjoyed your silly story!\n";
    }
    
    void playNumberGuessing() {
        cout << "\n(Numbers) NUMBER GUESSING (Numbers)\n";
        cout << "======================\n";
        cout << "I'm thinking of a number between 1 and 100!\n";
        cout << "Can you guess it?\n\n";
        
        int secret_number = (rand() % 100) + 1; // Use rand()
        int attempts = 0;
        int max_attempts = 7;
        int guess;
        
        while (attempts < max_attempts) {
            cout << "Attempts left: " << (max_attempts - attempts) << "\n";
            cout << "Your guess: ";
            cin >> guess;
            attempts++;
            
            if (guess == secret_number) {
                cout << "\n(Hooray!) Congratulations! You guessed it!\n";
                cout << "The number was " << secret_number << "\n";
                cout << "You won in " << attempts << " attempts!\n";
                return;
            } else if (guess < secret_number) {
                if (secret_number - guess > 20) {
                    cout << "(Higher) Too low! Way too low!\n";
                } else if (secret_number - guess > 10) {
                    cout << "(Higher) Too low! Getting warmer though!\n";
                } else {
                    cout << "(Higher) Too low! Very close!\n";
                }
            } else {
                if (guess - secret_number > 20) {
                    cout << "(Lower) Too high! Way too high!\n";
                } else if (guess - secret_number > 10) {
                    cout << "(Lower) Too high! Getting warmer though!\n";
                } else {
                    cout << "(Lower) Too high! Very close!\n";
                }
            }
            cout << "\n";
        }
        
        cout << "(Game Over) Game Over! The number was: " << secret_number << "\n";
    }
    
    void playWouldYouRather() {
        cout << "\n(Hmm) WOULD YOU RATHER (Hmm)\n";
        cout << "========================\n";
        cout << "Choose between two scenarios!\n\n";
        
        int rounds = 5;
        vector<bool> used(wyr_questions.size(), false);
        
        for (int round = 1; round <= rounds; round++) {
            cout << "Round " << round << "/" << rounds << "\n";
            cout << "================\n";
            
            // Pick a random unused question
            int question_index;
            do {
                question_index = rand() % (int)wyr_questions.size(); // Fix: signed/unsigned mismatch
            } while (used[question_index]);
            used[question_index] = true;
            
            pair<string, string> question = wyr_questions[question_index];
            
            cout << "Would you rather...\n";
            cout << "1. " << question.first << "\n";
            cout << "2. " << question.second << "\n";
            cout << "\nYour choice (1 or 2): ";
            
            int choice;
            cin >> choice;
            
            if (choice == 1) {
                cout << "(Choice) You chose: " << question.first << "\n";
            } else if (choice == 2) {
                cout << "(Choice) You chose: " << question.second << "\n";
            } else {
                cout << "(Shrug) Invalid choice! Let's say you chose option 1!\n";
            }
            
            // Add some fun responses
            vector<string> responses;
            responses.push_back("Interesting choice! (Hmm)");
            responses.push_back("Bold decision! (Strong)");
            responses.push_back("I can see why you'd pick that! (Hmm)");
            responses.push_back("That's a tough one! (Phew)");
            responses.push_back("Good choice! (Good)");
            responses.push_back("Hmm, I might have chosen differently! (Shrug)");
            
            cout << responses[rand() % (int)responses.size()] << "\n\n"; // Fix: signed/unsigned mismatch
        }
        
        cout << "(Hooray!) Thanks for playing Would You Rather!\n";
        cout << "Hope you enjoyed thinking about those scenarios!\n";
    }
    
    void playReversi() {
        vector<vector<char>> board(8, vector<char>(8, '.'));
        board[3][3] = 'W'; board[3][4] = 'B';
        board[4][3] = 'B'; board[4][4] = 'W';
        
        char currentPlayer = 'B';
        
        cout << "\n(Black)(White) REVERSI (White)(Black)\n";
        cout << "==================\n";
        cout << "Black (B) vs White (W)\n";
        cout << "Capture opponent pieces by surrounding them!\n";
        cout << "Enter moves as row,col (1-8)\n\n";
        
        while (true) {
            displayReversiBoard(board); // Use helper function
            pair<int, int> scores = countReversiPieces(board); // Use helper function
            cout << "Score - Black: " << scores.first << " | White: " << scores.second << "\n";
            
            if (!hasValidReversiMoves(board, currentPlayer)) { // Use helper function
                currentPlayer = (currentPlayer == 'B') ? 'W' : 'B';
                if (!hasValidReversiMoves(board, currentPlayer)) { // Use helper function
                    cout << "\n(Game Over) Game Over! Final Score:\n";
                    cout << "Black: " << scores.first << " | White: " << scores.second << "\n";
                    if (scores.first > scores.second) {
                        cout << "(Black) Black wins!\n";
                    } else if (scores.second > scores.first) {
                        cout << "(White) White wins!\n";
                    } else {
                        cout << "(Tie) It's a tie!\n";
                    }
                    return;
                }
            }
            
            cout << "Player " << currentPlayer << "'s turn\n";
            cout << "Enter row (1-8): ";
            int row;
            cin >> row;
            cout << "Enter column (1-8): ";
            int col;
            cin >> col;
            
            row--; col--; // Convert to 0-indexed
            
            if (row < 0 || row > 7 || col < 0 || col > 7) {
                cout << "Invalid position! Try again.\n";
                continue;
            }
            
            if (!isValidReversiMove(board, row, col, currentPlayer)) { // Use helper function
                cout << "Invalid move! Try again.\n";
                continue;
            }
            
            makeReversiMove(board, row, col, currentPlayer); // Use helper function
            currentPlayer = (currentPlayer == 'B') ? 'W' : 'B';
        }
    }
    
    void playSnake() {
        const int WIDTH = 20, HEIGHT = 10;
        vector<vector<char>> board(HEIGHT, vector<char>(WIDTH, '.')); // Local board for rendering
        vector<pair<int,int>> snake;
        snake.push_back(make_pair(HEIGHT/2, WIDTH/2)); // Initial snake head
        pair<int,int> food = make_pair(rand() % HEIGHT, rand() % WIDTH); // Use rand()
        int dx = 0, dy = 1; // Start moving right
        int score = 0;
        
        cout << "\n(Snake) SNAKE (Snake)\n";
        cout << "============\n";
        cout << "Use WASD to move! Eat food (@) to grow!\n";
        cout << "Don't hit walls or yourself!\n\n";
        
        cout << "Press Enter to start, then use W/A/S/D to move...\n";
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any leftover newline
        cin.get();    // Wait for Enter
        
        // Game loop
        while (true) {
            // Clear screen (Windows specific)
            system("cls"); 

            // Handle input
            if (_kbhit()) { // Check if a key has been pressed
                char input = _getch(); // Get the character without waiting for Enter
                input = toupper(input);
                
                // Update direction
                if (input == 'W' && dx != 1) { dx = -1; dy = 0; }
                else if (input == 'S' && dx != -1) { dx = 1; dy = 0; }
                else if (input == 'A' && dy != 1) { dx = 0; dy = -1; }
                else if (input == 'D' && dy != -1) { dx = 0; dy = 1; }
            }
            
            // Move snake
            pair<int,int> newHead = make_pair(snake[0].first + dx, snake[0].second + dy);
            
            // Check wall collision
            if (newHead.first < 0 || newHead.first >= HEIGHT || 
                newHead.second < 0 || newHead.second >= WIDTH) {
                cout << "\n(Game Over) Game Over! You hit a wall!\n";
                cout << "Final Score: " << score << "\n";
                Sleep(2000); // Pause for 2 seconds before returning to menu
                return;
            }
            
            // Check self collision
            for (size_t i = 0; i < snake.size(); ++i) { // Use size_t
                if (newHead.first == snake[i].first && newHead.second == snake[i].second) {
                    cout << "\n(Game Over) Game Over! You hit yourself!\n";
                    cout << "Final Score: " << score << "\n";
                    Sleep(2000); // Pause
                    return;
                }
            }
            
            snake.insert(snake.begin(), newHead);
            
            // Check food collision
            if (newHead.first == food.first && newHead.second == food.second) {
                score++;
                cout << "(Food) Yum! Score: " << score << "\n";
                // Generate new food
                do {
                    food = make_pair(rand() % HEIGHT, rand() % WIDTH); // Use rand()
                } while (find(snake.begin(), snake.end(), food) != snake.end());
            } else {
                snake.pop_back(); // Remove tail if no food eaten
            }

            // Prepare board for display
            vector<vector<char>> currentDisplayBoard(HEIGHT, vector<char>(WIDTH, '.'));
            for (size_t i = 0; i < snake.size(); ++i) {
                if (i == 0) {
                    currentDisplayBoard[snake[i].first][snake[i].second] = 'O'; // Head
                } else {
                    currentDisplayBoard[snake[i].first][snake[i].second] = 'o'; // Body
                }
            }
            currentDisplayBoard[food.first][food.second] = '@'; // Place food

            displaySnakeBoard(currentDisplayBoard, WIDTH, HEIGHT, score); // Pass the prepared board

            Sleep(200); // Control game speed
        }
    }
    
    void playPong() {
        const int WIDTH = 40, HEIGHT = 15;
        int paddleY = HEIGHT/2, ballX = WIDTH/2, ballY = HEIGHT/2;
        int ballDX = 1, ballDY = 1;
        int playerScore = 0, computerScore = 0;
        int computerPaddleY = HEIGHT/2;
        
        cout << "\n(Pong) PONG (Pong)\n";
        cout << "===========\n";
        cout << "Use W/S to move your paddle up/down!\n";
        cout << "First to 5 points wins!\n\n";
        
        cout << "Press Enter to start, then use W/S to move...\n";
        cin.ignore(numeric_limits<streamsize>::max(), '\n'); // Clear any leftover newline
        cin.get();    // Wait for Enter
        
        while (playerScore < 5 && computerScore < 5) {
            // Clear screen
            system("cls");

            // Handle input
            if (_kbhit()) {
                char input = _getch();
                input = toupper(input);
                
                // Update player paddle
                if (input == 'W' && paddleY > 1) paddleY--;
                else if (input == 'S' && paddleY < HEIGHT-2) paddleY++;
            }
            
            // Move ball
            ballX += ballDX;
            ballY += ballDY;
            
            // Ball collision with top/bottom walls
            if (ballY <= 0 || ballY >= HEIGHT-1) {
                ballDY = -ballDY;
            }
            
            // Ball collision with paddles
            if (ballX == 2 && ballY >= paddleY-1 && ballY <= paddleY+1) {
                ballDX = -ballDX;
            }
            if (ballX == WIDTH-3 && ballY >= computerPaddleY-1 && ballY <= computerPaddleY+1) {
                ballDX = -ballDX;
            }
            
            // Scoring
            if (ballX < 0) { // Ball went past player's paddle
                computerScore++;
                cout << "(Computer) Computer scores!\n";
                // Reset ball position and direction
                ballX = WIDTH/2; ballY = HEIGHT/2;
                ballDX = 1; ballDY = (rand() % 2) ? 1 : -1; // Use rand()
                Sleep(1000); // Pause for a moment after scoring
                continue; // Skip drawing board and continue loop
            } else if (ballX >= WIDTH) { // Ball went past computer's paddle
                playerScore++;
                cout << "(Hooray!) You score!\n";
                // Reset ball position and direction
                ballX = WIDTH/2; ballY = HEIGHT/2;
                ballDX = -1; ballDY = (rand() % 2) ? 1 : -1; // Use rand()
                Sleep(1000); // Pause
                continue; // Skip drawing board and continue loop
            }
            
            // Simple AI for computer paddle
            if (ballY < computerPaddleY && computerPaddleY > 1) {
                computerPaddleY--;
            } else if (ballY > computerPaddleY && computerPaddleY < HEIGHT-2) {
                computerPaddleY++;
            }

            // Prepare board for display
            vector<vector<char>> currentDisplayBoard(HEIGHT, vector<char>(WIDTH, ' '));
            // Draw paddles
            for (int i = 0; i < 3; i++) {
                if (paddleY + i - 1 >= 0 && paddleY + i - 1 < HEIGHT) {
                    currentDisplayBoard[paddleY + i - 1][1] = '|';
                }
                if (computerPaddleY + i - 1 >= 0 && computerPaddleY + i - 1 < HEIGHT) {
                    currentDisplayBoard[computerPaddleY + i - 1][WIDTH-2] = '|';
                }
            }
            // Draw ball
            if (ballX >= 0 && ballX < WIDTH && ballY >= 0 && ballY < HEIGHT) {
                currentDisplayBoard[ballY][ballX] = 'O';
            }
            // Draw borders
            for (int i = 0; i < WIDTH; i++) {
                currentDisplayBoard[0][i] = '-';
                currentDisplayBoard[HEIGHT-1][i] = '-';
            }

            displayPongBoard(currentDisplayBoard, WIDTH, HEIGHT, playerScore, computerScore); // Pass the prepared board
            Sleep(100); // Control game speed
        }
        
        // Final score display
        system("cls"); // Clear screen one last time
        // Create an empty board for final score display to avoid drawing game elements
        displayPongBoard(vector<vector<char>>(HEIGHT, vector<char>(WIDTH, ' ')), WIDTH, HEIGHT, playerScore, computerScore); 
        if (playerScore > computerScore) {
            cout << "(Trophy) You won! Final Score: " << playerScore << "-" << computerScore << "\n";
        } else {
            cout << "(Computer) Computer won! Final Score: " << computerScore << "-" << playerScore << "\n";
        }
        Sleep(2000); // Pause
    }
    
    void run() {
        displayLogo();
        
        while (true) {
            displayMenu();
            int choice;
            cin >> choice;
            
            switch (choice) {
                case 1:
                    playWordle();
                    break;
                case 2:
                    playHangman();
                    break;
                case 3:
                    playTicTacToe();
                    break;
                case 4:
                    playRockPaperScissors();
                    break;
                case 5:
                    playContexto();
                    break;
                case 6:
                    playMadLibs();
                    break;
                case 7:
                    playNumberGuessing();
                    break;
                case 8:
                    playWouldYouRather();
                    break;
                case 9:
                    playReversi();
                    break;
                case 10:
                    playSnake();
                    break;
                case 11:
                    playPong();
                    break;
                case 12:
                    cout << "\n(Bye!) Thanks for playing PlayWare Legacy Edition! See you next time!\n";
                    return;
                default:
                    cout << "\n(Wrong) Invalid choice! Please select 1-12.\n";
            }
            
            cout << "\nPress Enter to return to main menu...";
            // Clear input buffer before waiting for new line
            cin.ignore(numeric_limits<streamsize>::max(), '\n'); 
            cin.get(); // Wait for user to press Enter
        }
    }
};

// --- Helper Functions (replacing lambdas and for modularity) ---

// Tic Tac Toe Helpers
void displayTicTacToeBoard(const vector<vector<char>>& board) {
    cout << "   1   2   3\n";
    for (int i = 0; i < 3; i++) {
        cout << i + 1 << "  " << board[i][0] << " | " << board[i][1] << " | " << board[i][2] << "\n";
        if (i < 2) cout << "  -----------\n";
    }
    cout << "\n";
}

bool checkTicTacToeWin(const vector<vector<char>>& board, char player) {
    // Check rows, columns, and diagonals
    for (int i = 0; i < 3; i++) {
        if ((board[i][0] == player && board[i][1] == player && board[i][2] == player) ||
            (board[0][i] == player && board[1][i] == player && board[2][i] == player)) {
            return true;
        }
    }
    return (board[0][0] == player && board[1][1] == player && board[2][2] == player) ||
           (board[0][2] == player && board[1][1] == player && board[2][0] == player);
}

bool isTicTacToeBoardFull(const vector<vector<char>>& board) {
    for (int i = 0; i < 3; i++) {
        for (int j = 0; j < 3; j++) {
            if (board[i][j] == ' ') return false;
        }
    }
    return true;
}

// Reversi Helpers
void displayReversiBoard(const vector<vector<char>>& board) {
    cout << "   1 2 3 4 5 6 7 8\n";
    for (int i = 0; i < 8; i++) {
        cout << i + 1 << "  ";
        for (int j = 0; j < 8; j++) {
            cout << board[i][j] << " ";
        }
        cout << "\n";
    }
    cout << "\n";
}

bool isValidReversiMove(const vector<vector<char>>& board, int row, int col, char player) {
    if (board[row][col] != '.') return false;
    
    char opponent = (player == 'B') ? 'W' : 'B';
    
    // Check all 8 directions
    int directions[8][2] = {{-1,-1}, {-1,0}, {-1,1}, {0,-1}, {0,1}, {1,-1}, {1,0}, {1,1}};
    
    for (int d = 0; d < 8; d++) {
        int dr = directions[d][0], dc = directions[d][1];
        int r = row + dr, c = col + dc;
        bool foundOpponent = false;
        
        while (r >= 0 && r < 8 && c >= 0 && c < 8) {
            if (board[r][c] == opponent) {
                foundOpponent = true;
            } else if (board[r][c] == player && foundOpponent) {
                return true;
            } else {
                break;
            }
            r += dr;
            c += dc;
        }
    }
    return false;
}

void makeReversiMove(vector<vector<char>>& board, int row, int col, char player) {
    board[row][col] = player;
    char opponent = (player == 'B') ? 'W' : 'B';
    
    int directions[8][2] = {{-1,-1}, {-1,0}, {-1,1}, {0,-1}, {0,1}, {1,-1}, {1,0}, {1,1}};
    
    for (int d = 0; d < 8; d++) {
        int dr = directions[d][0], dc = directions[d][1];
        int r = row + dr, c = col + dc;
        vector<pair<int,int>> toFlip;
        
        while (r >= 0 && r < 8 && c >= 0 && c < 8) {
            if (board[r][c] == opponent) {
                toFlip.push_back(make_pair(r, c));
            } else if (board[r][c] == player && !toFlip.empty()) {
                for (size_t i = 0; i < toFlip.size(); ++i) { // Use size_t
                    board[toFlip[i].first][toFlip[i].second] = player;
                }
                break;
            } else {
                break;
            }
            r += dr;
            c += dc;
        }
    }
}

bool hasValidReversiMoves(const vector<vector<char>>& board, char player) {
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (isValidReversiMove(board, i, j, player)) return true;
        }
    }
    return false;
}

pair<int, int> countReversiPieces(const vector<vector<char>>& board) {
    int black = 0, white = 0;
    for (int i = 0; i < 8; i++) {
        for (int j = 0; j < 8; j++) {
            if (board[i][j] == 'B') black++;
            else if (board[i][j] == 'W') white++;
        }
    }
    return make_pair(black, white);
}

// Snake Helper
// Renamed 'board' parameter to 'gameGrid'
void displaySnakeBoard(const vector<vector<char>>& gameGrid, int width, int height, int score) {
    cout << "Score: " << score << "\n";
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            cout << gameGrid[i][j] << " "; // Use 'gameGrid' here
        }
        cout << "\n";
    }
}

// Pong Helper
// Renamed 'board' parameter to 'gameGrid'
void displayPongBoard(const vector<vector<char>>& gameGrid, int width, int height, int playerScore, int computerScore) {
    cout << "Player: " << playerScore << " | Computer: " << computerScore << "\n";
    for (int i = 0; i < height; i++) {
        for (int j = 0; j < width; j++) {
            cout << gameGrid[i][j]; // Use 'gameGrid' here
        }
        cout << "\n";
    }
}


int main() {
    PlayWareLegacyEditionHub hub;
    hub.run();
    return 0;
}
